--
-- Database: `event_manager`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance_t`
--

CREATE TABLE `attendance_t` (
  `event_id` int(11) NOT NULL,
  `participant_id` int(11) NOT NULL,
  `present` enum('no','yes') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `event_t`
--

CREATE TABLE `event_t` (
  `event_id` int(11) NOT NULL,
  `event_name` varchar(128) NOT NULL,
  `event_theme` varchar(128) NOT NULL,
  `event_location` varchar(128) NOT NULL,
  `event_time` varchar(16) NOT NULL,
  `event_date` varchar(32) NOT NULL,
  `event_status` enum('active','inactive') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event_t`
--

INSERT INTO `event_t` (`event_id`, `event_name`, `event_theme`, `event_location`, `event_time`, `event_date`, `event_status`) VALUES
(6, 'Testing', 'Beta', 'My House', '6:00PM', '2018-03-31', 'active'),
(7, 'Aquaintance Party', 'Shindig', 'DBTC New Gym', '6:00PM', '2018-08-23', 'active'),
(8, 'aaaaaa', 'gown', 'dbtc', '7:00', '12-12-21', 'active'),
(9, 'test', 'alpha', 'dbtc', '184500', '2018-05-12', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `participant_t`
--

CREATE TABLE `participant_t` (
  `participant_id` int(11) NOT NULL,
  `participant_name` varchar(128) NOT NULL,
  `participant_contact` varchar(16) NOT NULL,
  `participant_address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `participant_t`
--

INSERT INTO `participant_t` (`participant_id`, `participant_name`, `participant_contact`, `participant_address`) VALUES
(1, 'John Doe', '123-456-7890', '1235 Sue Lane Cebu City'),
(2, 'Jane Doe', '123123123', 'Movie Lane Cebu City');

-- --------------------------------------------------------

--
-- Table structure for table `raffle_t`
--

CREATE TABLE `raffle_t` (
  `raffle_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `participant_id` int(11) NOT NULL,
  `raffle_reward` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance_t`
--
ALTER TABLE `attendance_t`
  ADD PRIMARY KEY (`event_id`,`participant_id`),
  ADD KEY `participant_id` (`participant_id`);

--
-- Indexes for table `event_t`
--
ALTER TABLE `event_t`
  ADD PRIMARY KEY (`event_id`),
  ADD UNIQUE KEY `event_name` (`event_name`);

--
-- Indexes for table `participant_t`
--
ALTER TABLE `participant_t`
  ADD PRIMARY KEY (`participant_id`);

--
-- Indexes for table `raffle_t`
--
ALTER TABLE `raffle_t`
  ADD PRIMARY KEY (`raffle_id`,`event_id`),
  ADD KEY `event_id` (`event_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `event_t`
--
ALTER TABLE `event_t`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `participant_t`
--
ALTER TABLE `participant_t`
  MODIFY `participant_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance_t`
--
ALTER TABLE `attendance_t`
  ADD CONSTRAINT `attendance_t_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event_t` (`event_id`),
  ADD CONSTRAINT `attendance_t_ibfk_2` FOREIGN KEY (`participant_id`) REFERENCES `participant_t` (`participant_id`);

--
-- Constraints for table `raffle_t`
--
ALTER TABLE `raffle_t`
  ADD CONSTRAINT `raffle_t_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event_t` (`event_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
